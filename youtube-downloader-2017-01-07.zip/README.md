# youtube-video-downloader
Download videos from YouTube using wget and cURL
