<?php
include_once 'class.ErrorHandler.php';
$errorObj = ErrorHandler::getInstance();
$errorObj->enableHandler();
?>
