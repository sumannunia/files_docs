<?php 
//     $myFile = "filename.html"; // or .php   
//     $fh = fopen($myFile, 'w'); // or die("error");  
//     $stringData = '<!DOCTYPE html>
// <html lang="en">
// <head>
//     <meta charset="UTF-8">
//     <meta http-equiv="X-UA-Compatible" content="IE=edge">
//     <meta name="viewport" content="width=device-width, initial-scale=1.0">
//     <title>Document</title>
// </head>
// <body>
    
// </body>
// </html>';   
//     fwrite($fh, $stringData);
//     fclose($fh);


// $file = 'people.html';
// // The new person to add to the file
// $person = '<!DOCTYPE html>
// <html lang="en">
// <head>
//     <meta charset="UTF-8">
//     <meta http-equiv="X-UA-Compatible" content="IE=edge">
//     <meta name="viewport" content="width=device-width, initial-scale=1.0">
//     <title>Document</title>
// </head>
// <body>
    
// </body>
// </html>';

// Write the contents to the file, 
// using the FILE_APPEND flag to append the content to the end of the file
// and the LOCK_EX flag to prevent anyone else writing to the file at the same time
// file_put_contents($file, $person, FILE_APPEND | LOCK_EX);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Ballet&family=Montez&family=Montserrat:wght@400;500;600;700&family=PT+Sans:wght@400;700&family=Roboto&display=swap"
        rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" rel="stylesheet">

    <title>Cake for Birthday</title>
    <link rel="stylesheet" href="./css/common-style.css">
</head>
<body>
    <header class="bg-light">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <a class="navbar-brand" href="#">Birthday Cake <i class="fas fa-birthday-cake"></i></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                Dropdown
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>
                        
                    </ul>
                   
                </div>
            </nav>
        </div>
    </header>
    <main>
        <article class="theTop-bannerSection">
            <div class="container">
                <div class="row top-banner-row">
                    <div class="col-md-6 col-lg-7 top-banner-col mx-auto">
                        <div class="inside-top-banner-col">
                            <h3 class="thebrandname">
                                Name Birthday Cakes
                               
                            </h3>
                            <h3 class="descrip">
                                
                                Write Name on Cake Images
                            </h3>
                            <p class="the-descrip-top">
                                Send happy birthday wishes by writing name on birthday cake images via NameBirthdayCakes.net web app. Send birthday
                                quotes & wishes to friends, family members & others. Make a birthday special for your loved ones.
                            </p>
                        </div>
                    </div>
                    <!-- <div class="col-md-6 col-lg-5 top-banner-right-col ">
                        <div class="inside-the-right-col-top-banner">
                            <h5 class="theform-heading">Write name on cake</h5>
                            <form id="theCakeFormTop">
                                <div class="form-group">
                                    
                                    <input type="email" class="form-control" id="topFormnameInput" aria-describedby="emailHelp" placeholder="Enter Name / Wish here" required>   
                                </div>
                                <button type="submit" class="btn theCakeFormTopbtn">Generate Image Now</button>
                            </form>
                            <p class="thecaution-text">*Generate a random cake image with name</p>
                        </div>
                    </div> -->
                </div>
            </div>
           
        
        </article>
        <article class="main-content">
            <div class="container">
                <div class="name-section">
                    <div class="form-group">
                        <label for="forCommorName">Enter name here</label>
                        <input type="email" class="form-control" id="forCommorName" aria-describedby="emailHelp"
                            placeholder="Enter Name / Wish here" required oninput="updateUserName(this)">
                    </div>
                </div>
                <div class="row main-data" id="theRowForCols">
                    <div class="col-md-4 col-xl-3 thecard-col d-none">
                        <div class="inside-card-col">
                            <div class="image-container">
                                <img src="https://png.pngtree.com/png-vector/20190719/ourmid/pngtree-happy-birthday-cupcake-with-candle-png-image_1554181.jpg" alt="">
                                <div class="namesection">lorem ipsum</div>
                            </div>
                            <button class="btn" onclick="download()"><div class="spinner-border d-none theButtonspinner"></div> click</button>
                            <canvas id="can" class="" width="400" height="400" style="border:2px solid #000"></canvas>
                            <br />Font Family
                            <select id="fontFamily" name="font-control">
                                <option value="Arial" selected>Arial</option>
                                <option value="Times New Roman">Times</option>
                            </select><br />
                            
                            <br />
                            Effect : <select name="effect" id="effect">
                                <option value="curved">Curved</option>
                                <option value="arc">Arc</option>
                                <option value="STRAIGHT" selected>STRAIGHT</option>
                                <option value="smallToLarge">smallToLarge</option>
                                <option value="largeToSmallTop">largeToSmallToped</option>
                                <option value="largeToSmallBottom">largeToSmallBottom</option>
                                <option value="bulge">bulge</option>
                            </select><br>
                        </div>
                    </div>
                </div>
            </div>
        </article>
        <!-- <form action="./createFile.php" method="POST">
            <input type="text" name="generateFile">
        </form> -->
    </main>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/1.7.17/fabric.min.js"></script>
    <script src="https://rawgit.com/EffEPi/fabric.curvedText/master/fabric.curvedText.js"></script>

    <script src="./js/common-script.js"></script>
</body>
</html>