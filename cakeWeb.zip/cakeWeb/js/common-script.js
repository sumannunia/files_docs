console.log('Hellos');

const data = [
    {
         bgImage: "./card1.jpg",
         id: 1,
         color: "#222",
         font: "Ballet, cursive"
    },
    {
         bgImage: "http://i.imgur.com/tENv1w4.jpg",
         id: 2,
         color: "red",
         font: "PT Sans, sans-serif"
    },
    {
         bgImage: "./card1.jpg",
         id: 3,
         color: "green",
         font: "Montserrat, sans-serif"
    },
    {
         bgImage: "http://i.imgur.com/tENv1w4.jpg",
         id: 4,
         color: "#222",
         font: "Roboto, sans-serif"
    },
    {
         bgImage: "http://i.imgur.com/tENv1w4.jpg",
         id: 5,
         color: "#222",
         font: "Montez, cursive"
    }
];
let theCOntainer = document.getElementById('theRowForCols');
data.map(canva => {
    console.log(canva)
    let theCol = document.createElement('div');
    theCol.className = 'col-md-4 col-xl-3 thecard-col';
    theCol.innerHTML = `<div class="inside-card-col">
                            <div class="image-container">
                                <img src="${canva.bgImage}" alt="">
                                <div class="namesection" style="font-family: ${canva.font}"></div>
                            </div>
                            <button class="btn downloadbtn" onclick='download("${canva.bgImage}", "${canva.color}", ${canva.id}, "${canva.font}", this)'><div class=" d-none spinner-border  theButtonspinner" id="spinner${canva.id}"></div>Download</button>
                            <button class="btn downloadbtn mt-3" onclick='shareSave("${canva.bgImage}", "${canva.color}", ${canva.id}, "${canva.font}", this)'><div class=" d-none spinner-border  theButtonspinner" id="spinnerShare${canva.id}"></div>Share</button>
                        </div>`
    theCOntainer.appendChild(theCol);
})

let canvas = null;
let CurvedText = ""
$(function () {
    canvas = new fabric.Canvas('can');

    canvas.setHeight(400);
    canvas.setWidth(400);
    var img_src = './card1.jpg';
    var img = new Image();
    img.src = img_src;
    img.crossOrigin = "anonymous";  // important - set crossOrigin before src!
    img.onload = function(){
        canvas.setBackgroundImage(new fabric.Image(img, {
            width: canvas.width,
        height: canvas.height,
            originX: 'left',
            originY: 'top'
        }), canvas.renderAll.bind(canvas));
    };
    canvas.setZoom(canvas.getZoom() *1.0);
    
    CurvedText = new fabric.CurvedText($('#forCommorName').val(),{
                left: 200,
                top: 300,
                textAlign: 'center',
                fill: '#222',
                radius: 100,
                fontSize: 30,
                spacing: 7,
                effect:'STRAIGHT',
                fontFamily: '"Montez", cursive', 
                hasControls: false,
                originX: "center",

    });
    
    canvas.add(CurvedText).renderAll();
    canvas.setActiveObject(canvas.item(canvas.getObjects().length-1));
    // $('#effect').change(function(){
    //         var obj = canvas.getActiveObject();

    //         if(obj){
    //             obj.set($(this).attr('id'),$(this).val()); 
    //         }
    //         canvas.renderAll();
    //     });
    // $('#fontFamily').change(function(){
    //         var obj = canvas.getActiveObject();
    //         if(obj){
    //             obj.set($(this).attr('id'),$(this).val()); 
    //         }
    //         canvas.renderAll();
    //     });
    
});

function updateUserName(val){
    let text = val.value;
    // console.log(val)
    if(text.length < 18){

        $('.namesection').text(text);
    };
    CurvedText.setText(text);
    canvas.renderAll()
};
function download(bg, color, id, font, val){

    // canvas = new fabric.Canvas('can');
    let cakeName = $('#forCommorName').val();
    
    let ele = document.getElementById('spinner' + id);
    ele.classList.remove("d-none");
    console.log(val.children)
    async function lol()  {
        canvas.setHeight(400);
        canvas.setWidth(400);
        var img_src = bg;
        var img = new Image();
        img.src = img_src;
        img.crossOrigin = "anonymous";  // important - set crossOrigin before src!
        img.onload = function(){
            canvas.setBackgroundImage(new fabric.Image(img, {
                width: canvas.width,
            height: canvas.height,
                originX: 'left',
                originY: 'top'
            }), canvas.renderAll.bind(canvas));
        };
        canvas.setZoom(canvas.getZoom() *1.0);
        // CurvedText = new fabric.CurvedText('',{
        //     left: 200,
        //     top: 300,
        //     textAlign: 'center',
        //     fill: color,
        //     radius: 100,
        //     fontSize: 30,
        //     spacing: 7,
        //     effect:'STRAIGHT',
        //     fontFamily: '"Montez", cursive', 
        //     hasControls: false,
        //     originX: "center",

        // });
        CurvedText.setText($('#forCommorName').val());
        CurvedText.set({'fontFamily': font});
        canvas.add(CurvedText).renderAll(function(){
            
        });
        // canvas.setActiveObject(canvas.item(canvas.getObjects().length-1));
        canvas.deactivateAll();
        canvas.renderAll();
        return canvas;

    }
    lol()
    .then((canvas) => {
        setTimeout(() => {
            if(cakeName.length < 1) cakeName = "yourCake";
            var link = document.createElement('a');
            link.download = cakeName + '.png';
            link.href = document.getElementById('can').toDataURL('image/png')
            link.click();
            ele.classList.add("d-none");
        }, 3000)
    })
  
}
function shareSave(bg, color, id, font, val){


    let cakeName = $('#forCommorName').val();
    
    let ele = document.getElementById('spinnerShare' + id);
    ele.classList.remove("d-none");
    // console.log(val.children)
    async function lol()  {
        // canvas.setHeight(400);
        // canvas.setWidth(400);
        var img_src = bg;
        var img = new Image();
        img.src = img_src;
        img.crossOrigin = "anonymous";  // important - set crossOrigin before src!
        img.onload = function(){
            canvas.setBackgroundImage(new fabric.Image(img, {
                width: canvas.width,
            height: canvas.height,
                originX: 'left',
                originY: 'top'
            }), canvas.renderAll.bind(canvas));
        };
        canvas.setZoom(canvas.getZoom() *1.0);
        // CurvedText = new fabric.CurvedText('',{
        //     left: 200,
        //     top: 300,
        //     textAlign: 'center',
        //     fill: color,
        //     radius: 100,
        //     fontSize: 30,
        //     spacing: 7,
        //     effect:'STRAIGHT',
        //     fontFamily: '"Montez", cursive', 
        //     hasControls: false,
        //     originX: "center",

        // });
        CurvedText.setText($('#forCommorName').val());
        CurvedText.set({'fontFamily': font});
        canvas.add(CurvedText).renderAll(function(){
            
        });
        // canvas.setActiveObject(canvas.item(canvas.getObjects().length-1));
        canvas.deactivateAll();
        canvas.renderAll();
        return canvas;

    }
    lol()
    .then((canvas) => {
        setTimeout(() => {
            let theCanv = document.getElementById('can');
            if(cakeName.length < 1) cakeName = "yourCake";
            theCanv.toBlob((blob) => {
            let file = new File([blob], cakeName + ".jpeg", { type: "image/jpeg" });

            var formData = new FormData()
            
            formData.append('file', file);
            $.ajax({
                data: formData,
                type: "POST",
                // dataType: "JSON",
                url: './post.php',
                processData: false,
                contentType: false,
                complete: function (e) {

                            // progressElem.html("");
                            console.log("completed")
                            console.log(e)
                            
                            
                        },
                        success: function(e){
                            console.log(e)
                            let response = JSON.parse(e)
                            console.log(JSON.parse(e))
                            console.log(response)
                            if(response.message.toLowerCase() == 'success'){
                                 alert('Successful')
                                ele.classList.add("d-none");
                                console.log(response.FileName);
                                window.location.href = response.htmllink;
                            }else {
                                alert('sorry there is an error.')
                                ele.classList.add("d-none");
                            }
                            // if(e.message.toLowerCase().includes('success') ) 
                            // {
                                // alert('Successful')
                                // ele.classList.add("d-none");
                            // }
                            
                        }
            });
        
            }, 'image/jpeg');
        }, 3000)
    })
  
}