<?php
require_once "class.youtube.php";
$yt  = new YouTubeDownloader();
$downloadLinks ='';
$error='';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $videoLink = $_POST['video_link'];
    if(!empty($videoLink)) {
        $vid = $yt->getYouTubeCode($videoLink);
        if($vid) {
            $result = $yt->processVideo($vid);
            
            if($result) {
                //print_r($result);
                $info = $result['videos']['info'];
                $formats = $result['videos']['formats'];
                $adapativeFormats = $result['videos']['adapativeFormats'];

                

                $videoInfo = json_decode($info['player_response']);

                $title = $videoInfo->videoDetails->title;
                $thumbnail = $videoInfo->videoDetails->thumbnail->thumbnails{0}->url;
            }
            else {
                $error = "Something went wrong";
            }

        }
    }
    else {
        $error = "Please enter a YouTube video URL";
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/header-fotter.css">
    <link rel="stylesheet" href="./css/result.css">

    <title>Youtube similar search</title>
</head>

<body>
    <header class="bg-light">
        <nav class="navbar navbar-expand-lg navbar-light container ">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <main>
        <section>
            <article class="container article-for-search">
                <div class="theSearchInput">
                    <form class="d-flex" id="theSearchForm">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"
                            id="theSearchInput">
                        <button class="btn btn-outline-success " type="submit">Search</button>
                    </form>
                </div>
                <hr>
            </article>
            <article class="container thedata-section">
                <div class="row the-data-row">
                    <div class="col-md-12 col-lg-12 column-for-data-row">
                        <div class="left-col" id="theVidsRow">
                            <!-- <div class="spinner-star d-flex justify-content-center align-items-center">
                                <div class="spinner-border"></div>
                            </div> -->
                            <div class="theIframeSection">
                                <div class="titleTop">Download:  <span class="title-top-text">Lorem, ipsum dolor.</span></div>
                                <div class="theIframe">
                                    <iframe src="https://www.youtube.com/embed/-" frameborder="0"
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen class="theIframeMan"> </iframe>
                                </div>
                                <div class="file-name-of-video">
                                    Lorem ipsum dolor sit amet.
                                </div>
                                <!-- <div class="theDownLoadButton">
                                    <a href="https://www.mykidsdrawing.in/dashboard?lol" class="text-decoration-none theDownloadAnchor">Download video</a>
                                </div> -->
                            </div>
                            <?php if($error) :?>
                                    <div style="color:red;font-weight: bold;text-align: center"><?php print $error?></div>
                                <?php endif;?>

                                <?php if($formats):?>
                                

                                <div class="card formSmall">
                                    <div class="card-header">
                                        <strong>With Video & Sound</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table ">
                                            <tr>
                                                <td>Type</td>
                                                <td>Quality</td>
                                                <td>Download</td>
                                            </tr>
                                            <?php foreach ($formats as $video) :?>
                                                
                                                <tr>
                                                    <td><?php print $video['type']?></td>
                                                    <td><?php print $video['quality']?></td>
                                                    <!-- <td><a href="downloader.php?link=<?php print urlencode($video['link'])?>&title=<?php print urlencode($title)?>&type=<?php print urlencode($video['type'])?>">Download</a> </td> -->
                                                    <td><a href="javascript:void(0)" onclick="setlocalStorageBro(this.dataset.link)" data-link="downloader.php?link=<?php print urlencode($video['link'])?>&title=<?php print urlencode($title)?>&type=<?php print urlencode($video['type'])?>">Download</a> </td>
                                                </tr>
                                            <?php endforeach;?>
                                        </table>
                                    </div>
                                </div>

                                <div class="card formSmall">
                                    <div class="card-header">
                                        <strong>Videos video only/ Audios audio only</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table ">
                                            <tr>
                                                <td>Type</td>
                                                <td>Quality</td>
                                                <td>Download</td>
                                            </tr>
                                            <?php foreach ($adapativeFormats as $video) :?>
                                                <tr>
                                                    <td><?php print $video['type']?></td>
                                                    <td><?php print $video['quality']?></td>
                                                    <td><a href="downloader.php?link=<?php print urlencode($video['link'])?>&title=<?php print urlencode($title)?>&type=<?php print urlencode($video['type'])?>">Download</a> </td>
                                                </tr>
                                            <?php endforeach;?>
                                        </table>
                                    </div>
                                </div>
                                <?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
        </section>
    </main>
    <div class="footer">
        <footer>
            <article class="container">
                <ul class="list-unstyled the-footerul">
                    <a href="./index.html" class="text-decoration-none">
                        <li class="thefooter-nav-item">Home</li>
                    </a>
                    <a href="./privacy.html" class="text-decoration-none">
                        <li class="thefooter-nav-item">Privacy & Policy</li>
                    </a>
                    <a href="./contact.html" class="text-decoration-none">
                        <li class="thefooter-nav-item">Contact Us</li>
                    </a>
                </ul>
            </article>
        </footer>
    </div>


    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>
    <script src="./js/result.js"></script>

</body>

</html>