You can find the explanation for the simple YouTube downloader on the below link

https://www.tutsplanet.com/a-simple-youtube-video-downloader-script-in-php/
