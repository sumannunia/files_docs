let theName = document.getElementById("theFileName")
            let replaceText = theName.textContent.split('.')[0];
            theName.textContent = replaceText